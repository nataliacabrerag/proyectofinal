from ursina import *

app = Ursina()

cubo = Entity(model='cube', color=color.azure, scale=2)
app.run()
